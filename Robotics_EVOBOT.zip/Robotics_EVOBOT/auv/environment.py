import numpy as np

class Environment:
    def __init__(self, grid_size, cell_size, current_magnitude=0.1, current_direction=(1, 0, 0)):
        self.grid_size = grid_size
        self.cell_size = cell_size
        self.obstacles = {}
        self.current_magnitude = current_magnitude
        self.current_direction = np.array(current_direction) / np.linalg.norm(current_direction)
    
    def add_obstacle(self, position, velocity):
        self.obstacles[tuple(position)] = np.array(velocity) * self.cell_size
    
    def update_obstacles(self, time_step):
        new_obstacles = {}
        for pos, vel in self.obstacles.items():
            new_pos = np.array(pos) * self.cell_size + (vel + self.get_current(pos)) * time_step
            new_pos = np.clip(new_pos / self.cell_size, [0, 0, 0], np.array(self.grid_size) - 1)
            new_obstacles[tuple(new_pos.round().astype(int))] = vel
        self.obstacles = new_obstacles
    
    def get_current(self, position):
        return self.current_magnitude * self.current_direction
    
    def is_obstacle(self, position):
        return tuple((position / self.cell_size).round().astype(int)) in self.obstacles
    
    def is_within_bounds(self, position):
        pos = position / self.cell_size
        return (0 <= pos[0] < self.grid_size[0] and 
                0 <= pos[1] < self.grid_size[1] and 
                0 <= pos[2] < self.grid_size[2])