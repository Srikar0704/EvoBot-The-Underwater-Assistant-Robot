import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D

from environment import Environment
from planning import AStar3D
from robot import UnderwaterRobot

# --- Simulation Parameters ---
GRID_SIZE_XY = 10  # X and Y grid size (meters)
GRID_SIZE_Z = 30   # Z grid size (meters, for 20-30m depth)
CELL_SIZE = 1.0    # Meters per grid cell
DT = 0.2           # Time step

# Create the underwater environment
env = Environment((GRID_SIZE_XY, GRID_SIZE_XY, GRID_SIZE_Z), CELL_SIZE)

# Add moving obstacles with velocities
obstacle_coords = [
    ((3, 3, 3), (1, 0, 0)),   # Near surface
    ((5, 5, 15), (0, 1, 0)),  # Mid-depth
    ((7, 2, 25), (0, 0, 1)),  # Near 25m depth
]
for coord, velocity in obstacle_coords:
    env.add_obstacle(coord, velocity)

# Define the base position (near surface)
base_pos = np.array([0, 0, 0])

# --- Get User Destination ---
def get_user_destination():
    """Get user-defined destination coordinates."""
    while True:
        try:
            x, y, z = map(float, input(f"Enter destination (x y z) within grid (0-{GRID_SIZE_XY-1}, 0-{GRID_SIZE_XY-1}, 0-{GRID_SIZE_Z-1}): ").split())
            if (0 <= x < GRID_SIZE_XY and 0 <= y < GRID_SIZE_XY and 0 <= z < GRID_SIZE_Z):
                return np.array([x, y, z]) * CELL_SIZE  # Convert to meters
            else:
                print(f"❌ Invalid input! X/Y: 0-{GRID_SIZE_XY-1}, Z: 0-{GRID_SIZE_Z-1}")
        except ValueError:
            print("❌ Invalid format! Enter three numbers separated by spaces.")

# Get the first destination
user_target = get_user_destination()

# Initialize the robot with physical properties
robot = UnderwaterRobot(base_pos.copy(), density=900, volume=0.001, max_speed=1.0, max_pressure=3e6)  # 3 MPa tolerance
planner = AStar3D(env)

# Plan initial path
path = planner.plan(robot.position, user_target)
if path is None:
    print("❌ No path found to initial destination!")
    exit(1)
robot.set_path(path)

# --- Initial Terminal Output ---
print("\n--- Simulation Start ---")
print(f"Initial Position: {robot.position.round(2)}")
print(f"Final (Target) Position: {user_target.round(2)}")

# --- Data Storage ---
forces_history = []
currents_history = []
depth_history = []
pressure_history = []
robot_positions = [robot.position.copy()]

# --- Visualization Setup ---
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.set_xlim(0, GRID_SIZE_XY * CELL_SIZE)
ax.set_ylim(0, GRID_SIZE_XY * CELL_SIZE)
ax.set_zlim(0, GRID_SIZE_Z * CELL_SIZE)  # Depth up to 30m
ax.set_xlabel('X (m)')
ax.set_ylabel('Y (m)')
ax.set_zlabel('Z (m)')
ax.set_title("AUV Rescue Simulation with Deep Environment")

obstacle_scatter = ax.scatter([], [], [], c='r', marker='s', s=100)
ax.scatter([base_pos[0]], [base_pos[1]], [base_pos[2]], c='b', marker='o', s=150, label='Base')
target_scatter = ax.scatter([user_target[0]], [user_target[1]], [user_target[2]], c='g', marker='*', s=150, label='User Target')
planned_path_line, = ax.plot([], [], [], 'y--', label='Planned Path')
robot_path_line, = ax.plot([], [], [], 'c-', label='Robot Path')
robot_scatter = ax.scatter([robot.position[0]], [robot.position[1]], [robot.position[2]], c='m', marker='o', s=100, label='Robot')

def update(frame):
    global robot_positions, user_target, forces_history, currents_history, depth_history, pressure_history
    
    env.update_obstacles(time_step=frame * DT)
    obstacle_positions = np.array(list(env.obstacles.keys())) * CELL_SIZE
    if len(obstacle_positions) > 0:
        obstacle_scatter._offsets3d = (obstacle_positions[:, 0], obstacle_positions[:, 1], obstacle_positions[:, 2])
    
    pos = robot.move(DT, env, planner, user_target)
    robot_positions.append(pos.copy())
    
    if frame % 5 == 0:
        forces_history.append(robot.compute_forces(env))
        currents_history.append(env.get_current(pos))
        depth = pos[2]  # Z-coordinate is depth
        pressure = robot.compute_pressure(depth)
        depth_history.append(depth)
        pressure_history.append(pressure)
    
    robot_scatter._offsets3d = ([pos[0]], [pos[1]], [pos[2]])
    pos_arr = np.array(robot_positions)
    robot_path_line.set_data(pos_arr[:, 0], pos_arr[:, 1])
    robot_path_line.set_3d_properties(pos_arr[:, 2])
    
    if robot.path:
        path_arr = np.array(robot.path)
        planned_path_line.set_data(path_arr[:, 0], path_arr[:, 1])
        planned_path_line.set_3d_properties(path_arr[:, 2])

    # Debug distance
    distance_to_target = np.linalg.norm(robot.position - user_target)
    if frame % 10 == 0:
        print(f"Debug: Distance to target = {distance_to_target:.2f} meters, Depth = {pos[2]:.2f} m")

    if distance_to_target < 0.5:
        print(f"✅ Robot reached {user_target.round(2)}!")
        pos_arr = np.array(robot_positions)
        distance_traveled = np.sum(np.linalg.norm(np.diff(pos_arr, axis=0), axis=1))
        
        print("\n--- Forces, Currents, Depth, and Pressure During Simulation ---")
        print("Types of Forces: Buoyancy, Weight, Drag")
        for i, (forces, current, depth, pressure) in enumerate(zip(forces_history, currents_history, depth_history, pressure_history)):
            print(f"Sample {i+1}: Forces (N) = {forces.round(2)}, Water Current = {current.round(2)}, Depth = {depth:.2f} m, Pressure = {pressure:.2f} Pa")
        
        print("\n--- Simulation End ---")
        print(f"Distance Traveled: {distance_traveled:.2f} meters")
        
        new_target = get_user_destination()
        robot.path = planner.plan(robot.position, new_target)
        if robot.path is None:
            print("❌ No path found to new target!")
            exit(1)
        user_target = new_target
        target_scatter._offsets3d = ([user_target[0]], [user_target[1]], [user_target[2]])
        
        forces_history.clear()
        currents_history.clear()
        depth_history.clear()
        pressure_history.clear()
        robot_positions = [robot.position.copy()]

    return robot_scatter, robot_path_line, planned_path_line, obstacle_scatter, target_scatter

ani = FuncAnimation(fig, update, frames=300, interval=DT*1000, blit=False)
ax.legend()
plt.show()