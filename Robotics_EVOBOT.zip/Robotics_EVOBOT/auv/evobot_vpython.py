import numpy as np
from vpython import *
import matplotlib.pyplot as plt

from environment import Environment
from planning import AStar3D
from robot import UnderwaterRobot

# --- Simulation Parameters ---
GRID_SIZE_XY = 30
GRID_SIZE_Z = 30
CELL_SIZE = 1.0
DT = 0.2

# --- Get User-Defined Water Current ---
def get_water_current():
    while True:
        try:
            magnitude = float(input("Enter water current magnitude (m/s, e.g., 0.1): "))
            if magnitude < 0:
                print("❌ Magnitude must be non-negative!")
                continue
            direction_str = input("Enter water current direction (left or right): ").strip().lower()
            if direction_str == "left":
                direction = np.array([-1, 0, 0])
            elif direction_str == "right":
                direction = np.array([1, 0, 0])
            else:
                print("❌ Invalid direction! Enter 'left' or 'right'.")
                continue
            return magnitude, direction
        except ValueError:
            print("❌ Invalid input! Enter a number for magnitude.")

current_magnitude, current_direction = get_water_current()
print(f"Water Current Set: Magnitude = {current_magnitude} m/s, Direction = {current_direction.round(2)} ({'left' if current_direction[0] < 0 else 'right'})")

# Create the underwater environment
env = Environment((GRID_SIZE_XY, GRID_SIZE_XY, GRID_SIZE_Z), CELL_SIZE, current_magnitude, current_direction)

# Add moving obstacles with velocities
obstacle_coords = [
    ((3, 3, 3), (1, 0, 0)),
    ((5, 5, 15), (0, 1, 0)),
    ((7, 2, 25), (0, 0, 1)),
]
for coord, velocity in obstacle_coords:
    env.add_obstacle(coord, velocity)

# Define the base position (on surface, Z = 0)
base_pos = np.array([4.5, 0.5, 0.0])

# --- Get User Destination ---
def get_user_destination():
    while True:
        try:
            x, y, z = map(float, input(f"Enter destination (x y z) within grid (0-{GRID_SIZE_XY-1}, 0-{GRID_SIZE_XY-1}, 0-{GRID_SIZE_Z-1}), Z = depth: ").split())
            if (0 <= x < GRID_SIZE_XY and 0 <= y < GRID_SIZE_XY and 0 <= z < GRID_SIZE_Z):
                return np.array([x, y, z]) * CELL_SIZE
            else:
                print(f"❌ Invalid input! X/Y: 0-{GRID_SIZE_XY-1}, Z (depth): 0-{GRID_SIZE_Z-1}")
        except ValueError:
            print("❌ Invalid format! Enter three numbers separated by spaces.")

# Get the first destination
user_target = get_user_destination()

# Initialize the robot
robot = UnderwaterRobot(base_pos.copy(), density=900, volume=0.001, max_speed=1.0, max_pressure=3e6)
planner = AStar3D(env)

# Plan initial path
path = planner.plan(robot.position, user_target)
if path is None:
    print("❌ No path found to initial destination!")
    exit(1)
robot.set_path(path)

# --- Initial Terminal Output ---
print("\n--- Simulation Start ---")
print(f"Initial Position: {robot.position.round(2)} (Z = 0, surface at top)")
print(f"Final (Target) Position: {user_target.round(2)}")
print("\nControls:")
print("- Rotate: Right-click and drag")
print("- Zoom: Scroll wheel")
print("- Pan: Middle-click and drag (or Shift + left-click)")
print("- End Simulation: Click the 'End Simulation' button")
print("- Show Graphs: Click the 'Show Graphs' button after simulation")

# --- VPython Scene Setup ---
scene = canvas(title="EvoBot - Underwater Assistant Robot", width=800, height=600)
scene.range = 20
scene.center = vector(GRID_SIZE_XY * CELL_SIZE / 2, GRID_SIZE_XY * CELL_SIZE / 2, GRID_SIZE_Z * CELL_SIZE / 2)
scene.up = vector(0, 0, -1)
scene.forward = vector(0, -1, -0.5)

# Cuboid (30x30x30 meters, water body)
cuboid = box(pos=vector(GRID_SIZE_XY * CELL_SIZE / 2, GRID_SIZE_XY * CELL_SIZE / 2, GRID_SIZE_Z * CELL_SIZE / 2),
             size=vector(30, 30, 30),
             color=color.blue,
             opacity=0.1)

# Surface plane (at Z = 0, top of scene, 30x30)
surface = box(pos=vector(GRID_SIZE_XY * CELL_SIZE / 2, GRID_SIZE_XY * CELL_SIZE / 2, 0),
              size=vector(30, 30, 0.1),
              color=vector(0, 0.2, 0.4),
              opacity=0.3)

# Base (blue sphere, on surface)
base = sphere(pos=vector(base_pos[0], base_pos[1], base_pos[2]), 
              radius=0.3, 
              color=vector(0, 0, 0.5))

# Target (green sphere, deeper = lower in scene)
target = sphere(pos=vector(user_target[0], user_target[1], user_target[2]), 
                radius=0.3, 
                color=color.yellow)

# Robot (magenta sphere, starts on surface)
robot_obj = sphere(pos=vector(robot.position[0], robot.position[1], robot.position[2]), 
                   radius=0.5, 
                   color=vector(0, 0, 0.5),
                   make_trail=True, 
                   trail_type="points", 
                   trail_color=color.white, 
                   trail_radius=0.05)

# Obstacles (red cubes, now moving obstacles)
obstacles_obj = []
for pos in env.obstacles.keys():
    pos_m = np.array(pos) * CELL_SIZE
    obstacles_obj.append(box(pos=vector(pos_m[0], pos_m[1], pos_m[2]), 
                             size=vector(CELL_SIZE, CELL_SIZE, CELL_SIZE), 
                             color=vector(0, 0.8, 0.8),
                             opacity=0.7))

# Robot trajectory (cyan curve)
robot_traj = curve(color=color.white, radius=0.1)
robot_traj.append(vector(robot.position[0], robot.position[1], robot.position[2]))

# Water current arrow (at top center of cuboid)
current_arrow = arrow(pos=vector(GRID_SIZE_XY * CELL_SIZE / 2, GRID_SIZE_XY * CELL_SIZE / 2, 0),
                      axis=vector(current_magnitude * current_direction[0] * 5, 
                                  current_magnitude * current_direction[1] * 5, 
                                  current_magnitude * current_direction[2] * 5),
                      color=color.white,
                      shaftwidth=0.2)

# 3D Axis at bottom-left corner (0, 0, 30)
axis_length = 3
x_axis = arrow(pos=vector(0, 0, GRID_SIZE_Z * CELL_SIZE), 
               axis=vector(axis_length, 0, 0), 
               color=color.red, 
               shaftwidth=0.1, 
               opacity=0.8)
y_axis = arrow(pos=vector(0, 0, GRID_SIZE_Z * CELL_SIZE), 
               axis=vector(0, axis_length, 0), 
               color=color.green, 
               shaftwidth=0.1, 
               opacity=0.8)
z_axis = arrow(pos=vector(0, 0, GRID_SIZE_Z * CELL_SIZE), 
               axis=vector(0, 0, -axis_length), 
               color=color.blue, 
               shaftwidth=0.1, 
               opacity=0.8)

# --- Buttons for Control ---
end_simulation = False
def end_sim():
    global end_simulation
    end_simulation = True
    print("Simulation ending...")

button(text="End Simulation", pos=scene.title_anchor, bind=end_sim)

# Define plot_graphs globally so it can be called by the button
def plot_graphs(time_steps, depth_history, pressure_history, forces_history, velocities_history):
    fig, axs = plt.subplots(3, 1, figsize=(10, 12))
    
    axs[0].plot(time_steps, pressure_history, label='Pressure (Pa)', color='blue')
    axs[0].set_xlabel('Time (s)')
    axs[0].set_ylabel('Pressure (Pa)')
    axs[0].set_title('Pressure vs Time')
    axs[0].legend()
    axs[0].grid()
    
    velocities_magnitude = [np.linalg.norm(v) for v in velocities_history]
    axs[1].plot(time_steps, velocities_magnitude, label='Velocity (m/s)', color='red')
    axs[1].set_xlabel('Time (s)')
    axs[1].set_ylabel('Velocity (m/s)')
    axs[1].set_title('Velocity vs Time')
    axs[1].legend()
    axs[1].grid()
    
    forces_magnitude = [np.linalg.norm(f) for f in forces_history]
    axs[2].plot(time_steps, forces_magnitude, label='Force (N)', color='green')
    axs[2].set_xlabel('Time (s)')
    axs[2].set_ylabel('Force (N)')
    axs[2].set_title('Forces vs Time')
    axs[2].legend()
    axs[2].grid()
    
    plt.tight_layout()
    plt.show()

# Show Graphs button
def show_graphs():
    if time_steps:  # Only plot if there’s data
        print("Displaying graphs...")
        plot_graphs(time_steps, depth_history, pressure_history, forces_history, velocities_history)
    else:
        print("No data available to plot yet!")

button(text="Show Graphs", pos=scene.title_anchor, bind=show_graphs)

# --- Data Storage ---
forces_history = []
currents_history = []
depth_history = []
pressure_history = []
velocities_history = []
time_steps = []
robot_positions = [robot.position.copy()]

# Flag to track if robot is rising to surface
rising_to_surface = False

# --- Simulation Loop ---
frame = 0
while frame < 300 and not end_simulation:
    rate(1 / DT)  # 5 Hz

    # Update environment
    env.update_obstacles(time_step=frame * DT)
    
    # Update obstacle positions
    for i, (pos, _) in enumerate(env.obstacles.items()):
        pos_m = np.array(pos) * CELL_SIZE
        obstacles_obj[i].pos = vector(pos_m[0], pos_m[1], pos_m[2])

    # Move robot
    pos = robot.move(DT, env, planner, user_target)
    robot_positions.append(pos.copy())
    
    # Store data every 5 frames
    if frame % 5 == 0:
        forces = robot.compute_forces(env)
        current = env.get_current(pos)
        depth = pos[2]
        pressure = robot.compute_pressure(depth)
        velocity = (pos - robot_positions[-2]) / DT if len(robot_positions) > 1 else np.zeros(3)
        
        forces_history.append(forces)
        currents_history.append(current)
        depth_history.append(depth)
        pressure_history.append(pressure)
        velocities_history.append(velocity)
        time_steps.append(frame * DT)

    # Update VPython objects
    robot_obj.pos = vector(pos[0], pos[1], pos[2])
    robot_traj.append(vector(pos[0], pos[1], pos[2]))

    # Debug distance and current effect
    distance_to_target = np.linalg.norm(robot.position - user_target)
    current_effect = env.get_current(robot.position)
    effective_velocity = (pos - robot_positions[-2]) / DT if len(robot_positions) > 1 else np.zeros(3)
    if frame % 10 == 0:
        print(f"Debug: Distance to target = {distance_to_target:.2f} m, Depth = {pos[2]:.2f} m, Current = {current_effect.round(2)} m/s, Velocity = {effective_velocity.round(2)} m/s")

    # Check if target reached
    if distance_to_target < 0.5 and not rising_to_surface:
        print(f"✅ Robot reached {user_target.round(2)}!")
        pos_arr = np.array(robot_positions)
        distance_traveled = np.sum(np.linalg.norm(np.diff(pos_arr, axis=0), axis=1))
        
        print("\n--- Forces, Currents, Depth, and Pressure During Simulation ---")
        print("Types of Forces: Buoyancy, Weight, Drag, Water Current")
        for i, (forces, current, depth, pressure) in enumerate(zip(forces_history, currents_history, depth_history, pressure_history)):
            print(f"Sample {i+1}: Forces (N) = {forces.round(2)}, Water Current = {current.round(2)}, Depth = {depth:.2f} m, Pressure = {pressure:.2f} Pa")
        
        print(f"Distance Traveled: {distance_traveled:.2f} meters")
        print("Robot is now rising to the surface...")

        # Set new target to surface
        surface_target = np.array([robot.position[0], robot.position[1], 0])
        robot.path = planner.plan(robot.position, surface_target)
        if robot.path is None:
            print("❌ No path found to surface!")
            break
        user_target = surface_target
        rising_to_surface = True
        forces_history.clear()
        currents_history.clear()
        depth_history.clear()
        pressure_history.clear()
        velocities_history.clear()
        time_steps.clear()
        robot_positions = [robot.position.copy()]

    # Check if reached surface
    if rising_to_surface and np.allclose(robot.position[2], 0, atol=0.5):
        print(f"✅ Robot reached surface at {robot.position.round(2)}!")
        rising_to_surface = False
        
        # Get new target
        new_target = get_user_destination()
        robot.path = planner.plan(robot.position, new_target)
        if robot.path is None:
            print("❌ No path found to new target!")
            break
        user_target = new_target
        target.pos = vector(user_target[0], user_target[1], user_target[2])
        print(f"New Target Position: {user_target.round(2)}")
        
        forces_history.clear()
        currents_history.clear()
        depth_history.clear()
        pressure_history.clear()
        velocities_history.clear()
        time_steps.clear()
        robot_positions = [robot.position.copy()]

    frame += 1

# Finalize simulation
if not end_simulation:
    print("Simulation completed! Click 'Show Graphs' to view results.")
else:
    print("Simulation terminated by user. Click 'Show Graphs' to view collected data if available.")