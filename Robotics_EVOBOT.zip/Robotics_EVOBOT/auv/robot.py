import numpy as np

class UnderwaterRobot:
    def __init__(self, position, density, volume, max_speed, max_pressure):
        self.position = np.array(position, dtype=float)
        self.density = density  # kg/m^3
        self.volume = volume    # m^3
        self.max_speed = max_speed  # m/s
        self.max_pressure = max_pressure  # Pa
        self.path = None
    
    def set_path(self, path):
        self.path = path
    
    def compute_forces(self, env):
        g = 9.81  # m/s^2
        rho_water = 1000  # kg/m^3
        
        # Buoyancy
        buoyancy = rho_water * self.volume * g
        
        # Weight
        weight = -self.density * self.volume * g
        
        # Drag (simplified, assuming constant velocity)
        velocity = self.max_speed / 2  # Placeholder
        drag_coeff = 0.1
        drag = -drag_coeff * velocity
        
        # Water current effect
        water_current = env.get_current(self.position)
        
        return np.array([0, 0, buoyancy + weight + drag]) + water_current
    
    def move(self, dt, env, planner, target):
        if self.path is None or len(self.path) == 0:
            self.path = planner.plan(self.position, target)
            if self.path is None:
                return self.position
        
        next_pos = self.path[0]
        direction = next_pos - self.position
        distance = np.linalg.norm(direction)
        
        # Get water current at current position
        water_current = env.get_current(self.position)
        current_magnitude = np.linalg.norm(water_current)
        
        if distance > 0:
            # Base step size without current
            step = min(self.max_speed * dt, distance)
            velocity = direction / distance * step
            
            # Adjust velocity based on water current (scaled for balance)
            effective_velocity = velocity - water_current * dt * 0.5  # Reduced current impact
            effective_speed = np.linalg.norm(effective_velocity)
            
            # Ensure minimum progress if struggling against current
            if effective_speed < 0.05 * self.max_speed:  # Lowered threshold
                effective_velocity = direction / distance * (0.05 * self.max_speed)  # Minimum speed
            elif effective_speed > self.max_speed:
                effective_velocity = effective_velocity / effective_speed * self.max_speed
            
            next_pos_grid = self.position + effective_velocity
            
            # Check for obstacles and boundaries
            if env.is_within_bounds(next_pos_grid) and not env.is_obstacle(next_pos_grid):
                depth = next_pos_grid[2]
                pressure = self.compute_pressure(depth)
                if pressure < self.max_pressure:
                    self.position = next_pos_grid
                    if np.allclose(self.position, next_pos, atol=0.1):
                        self.path.pop(0)
            else:
                # Replan if blocked
                self.path = planner.plan(self.position, target)
                if self.path:
                    next_pos = self.path[0]
                    direction = next_pos - self.position
                    distance = np.linalg.norm(direction)
                    if distance > 0:
                        step = min(self.max_speed * dt, distance)
                        velocity = direction / distance * step
                        effective_velocity = velocity - water_current * dt * 0.5
                        effective_speed = np.linalg.norm(effective_velocity)
                        if effective_speed < 0.05 * self.max_speed:
                            effective_velocity = direction / distance * (0.05 * self.max_speed)
                        elif effective_speed > self.max_speed:
                            effective_velocity = effective_velocity / effective_speed * self.max_speed
                        self.position += effective_velocity
        
        return self.position
    
    def compute_pressure(self, depth):
        rho_water = 1000  # kg/m^3
        g = 9.81  # m/s^2
        return rho_water * g * depth