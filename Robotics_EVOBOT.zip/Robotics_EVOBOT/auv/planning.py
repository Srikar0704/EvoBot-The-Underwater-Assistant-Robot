import numpy as np
from heapq import heappush, heappop

class AStar3D:
    def __init__(self, env):
        self.env = env
        self.counter = 0
    
    def heuristic(self, a, b):
        return np.linalg.norm(np.array(a) - np.array(b))
    
    def get_neighbors(self, position):
        neighbors = []
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                for dz in [-1, 0, 1]:
                    if dx == 0 and dy == 0 and dz == 0:
                        continue
                    neighbor = position + np.array([dx, dy, dz]) * self.env.cell_size
                    if (self.env.is_within_bounds(neighbor) and 
                        not self.env.is_obstacle(neighbor)):
                        neighbors.append(neighbor)
        return neighbors
    
    def plan(self, start, goal):
        start = np.array(start)
        goal = np.array(goal)
        
        start_grid = (start / self.env.cell_size).round() * self.env.cell_size
        goal_grid = (goal / self.env.cell_size).round() * self.env.cell_size
        
        if not self.env.is_within_bounds(start_grid) or not self.env.is_within_bounds(goal_grid):
            return None
        
        if self.env.is_obstacle(start_grid) or self.env.is_obstacle(goal_grid):
            return None
        
        open_set = []
        self.counter = 0
        heappush(open_set, (0, self.counter, start_grid))
        self.counter += 1
        
        came_from = {}
        g_score = {tuple(start_grid): 0}
        f_score = {tuple(start_grid): self.heuristic(start_grid, goal_grid)}
        
        while open_set:
            current_f, _, current = heappop(open_set)
            
            if np.allclose(current, goal_grid):
                path = []
                current_tuple = tuple(current)
                while current_tuple in came_from:
                    path.append(current)
                    current = came_from[current_tuple]
                    current_tuple = tuple(current)
                path.append(start_grid)
                return path[::-1]
            
            for neighbor in self.get_neighbors(current):
                current_effect = self.env.get_current(current)
                tentative_g_score = (g_score[tuple(current)] + 
                                   np.linalg.norm(neighbor - current) + 
                                   np.linalg.norm(current_effect) * 0.1)
                
                neighbor_tuple = tuple(neighbor)
                if tentative_g_score < g_score.get(neighbor_tuple, float('inf')):
                    came_from[neighbor_tuple] = current
                    g_score[neighbor_tuple] = tentative_g_score
                    f_score[neighbor_tuple] = tentative_g_score + self.heuristic(neighbor, goal_grid)
                    heappush(open_set, (f_score[neighbor_tuple], self.counter, neighbor))
                    self.counter += 1
        
        return None